module.exports = {
    key: "d351bad3232b991f86505eaa3ba28df8",
    base: "https://api.openweathermap.org/data/2.5/",
  };
  